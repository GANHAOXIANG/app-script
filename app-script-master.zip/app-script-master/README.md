# app脚本

#### 介绍
羊毛app脚本,作者qq 1056211611

#### 使用说明

1.  一般都是在脚本里面说明,自行打开脚本可查看

2.  脚本适合shuye，v4，青龙，面板，v2p也可以

v2p不会写重写，所以脚本需要变量都自行抓包添加

3.  完全适配v2p的自行找大佬写

4.讨论tg群:https://t.me/joinchat/8D2_IDN5t0A2ZmM1

5.tg频道:https://t.me/soy_pull

